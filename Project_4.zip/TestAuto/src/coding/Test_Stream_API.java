package coding;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.*;

public class Test_Stream_API {
	
	
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List<String> names = new ArrayList<String>();
		names.add("Ajeet");
		names.add("Negan");
		names.add("Aditya");
		names.add("Steve");
			
		//Using Stream and Lambda expression
		//long count = names.stream().filter(str->str.length()<6).count();
	//	System.out.println("There are "+count+" strings with length less than 6");
		
	//	int count_1;
		
		Stream.iterate(1, count->count+1)
		.filter(number->number%5==0)
		.limit(10)
		.forEach(System.out::println);

	}

}
