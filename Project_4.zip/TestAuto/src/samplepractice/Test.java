package samplepractice;

public class Test extends BaseTest {
	
	
	void print(){
		
		System.out.println("Printing Test Class Method");
	}
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		BaseTest b = new Test();
		b.print();
  
	}

}
