package samplepractice;

public class BaseTest {
	
	void print(){
		
		System.out.println("Printing Base Test Print method");
		
	}

}
