package com.test;

import java.io.File;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.swing.plaf.FileChooserUI;
import javax.xml.xpath.XPath;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import automation_POC.HomePage;
import automation_POC.TestBase;

public class SpiceJetAutomation  {
	

//	@Test
//	public void init(){
//		HomePage loginpage =  
//		           PageFactory.initElements(driver, 
//		        		   HomePage.class);
//		
//	String title = loginpage.getTitle();
//			
//			System.out.println("---"+title);
//		
//	}
	
	
	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver;
		driver =new ChromeDriver();
		
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		//driver.get("http://demo.automationtesting.in/Register.html");
		
		driver.get("https://www.softwaretestingmaterial.com/sample-webpage-to-automate/");
	//	driver.navigate().refresh();
//		HomePage hmpage = PageFactory.initElements(driver, HomePage.class);
//	
//				 String title = hmpage.getTitle();
//		
//		 System.out.println(title);
		 
		 
		 WebElement mySelectElement = driver.findElement(By.xpath("//div[@class='entry-content']//select[@class='spTextField']"));
		 Select dropdown= new Select(mySelectElement);
		 //To select an option - selectByVisibleText, selectByIndex, selectByValue
		 //selectByVisibleText
	      dropdown.selectByVisibleText("Performance Testing");
	      dropdown.selectByIndex(3);
		 List<WebElement> list = dropdown.getAllSelectedOptions();
		List<WebElement> listofOptions = dropdown.getOptions();
		for(WebElement ele1 : listofOptions){
			 System.out.println("----"+ele1.getText());
		  }
		 
		  
		
		WebElement a = dropdown.getFirstSelectedOption();
		System.out.println("---a---" +a.getText());
		 
		  for(WebElement ele : list){
			 System.out.println(ele.getText());
		  }
		 
		 Thread.sleep(2000);
		 
		
		// driver.findElement(By.xpath("//input[@value='Departure City']")).click();
	
	   //driver.findElement(By.xpath("//*[@id=\"dropdownGroup1\"]/div/ul[1]/li[3]/a"));
		
		// driver.findElement(By.xpath("//*[@id=\"dropdownGroup1\"]/div/ul[1]/li[3]/a")).click();
		
		// driver.findElement(By.xpath("//input[@value='Arrival City']")).click();
		
		//driver.findElement(By.xpath("//*[@id=\"dropdownGroup1\"]/div/ul[1]/li[3]/a")).click();
		// driver.findElement(By.linkText(" Bengaluru (BLR)"));
		// List<WebElement> list=driver.findElements(By.tagName("href"));
		//System.out.println(list.size);
		
		
		driver.close();
		
	}

	
	
	
}
