package com.test;

//import java.sql.Array;
//import java.lang.reflect.Array;
import java.util.Arrays;

public class SampleTest {
	
	public static int removeDuplicateElements(int arr[], int n){  
        if (n==0 || n==1){  
            return n;  
        }  
        int[] temp = new int[n];  
        int j = 0;  
        for (int i=0; i<n-1; i++){  
            if (arr[i] != arr[i+1]){  
                temp[j++] = arr[i];  
            }  
         }  
        temp[j++] = arr[n-1];     
        // Changing original array  
        for (int i=0; i<j; i++){  
            arr[i] = temp[i];  
        }  
        return j;  
    }  

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		   int arr[] = {10,20,20,30,30,40,50,50};  
	        int length = arr.length;  
		
	        int len = removeDuplicateElements(arr,length);
	        
	        System.out.println(len);
		
	        for (int i=0; i<length; i++){
	        	 System.out.print(arr[i]+" ");  
	        }
		
	        System.out.println();
		System.out.println('j'+'a'+'v'+'a');
		
		System.out.println("abc"+3+2); // Output: abc32

		System.out.println(3+2+"abc"); //Output: 5abc

//		int [] s = new int[3];
//		System.out.println(Arrays.toString(s));
		
		
		//int length;
		//Array num = new Array();
		
		
		int [] inarray = {2,3,4,5,5,6,7};
		
//		for (int a :inarray){
//			
//			System.out.println(a);
//		}
		
		int a = 0;
		int sum=0;
		
		int [][] multi = {	{10,3,4},
							{6,7,8},
							{9,0,3} };
		
		System.out.println("--"+Arrays.deepToString(multi));
		
		for (int k = 0; k < multi.length; k++) {

			for (int j = 0; j < multi.length; j++) {

				if (k == j) {
					sum += multi[k][j];

				}

				
				System.out.print(multi[k][j] + " ");

				a += multi[k][j];

			}

			System.out.println("----" + a);
			a = 0;
			System.out.println();

		}
		
		System.out.println("__"+sum);

		String s ="SARANG";
		
		String fch =  s.substring(5,6);
		
		String remainStr = s.substring(0,s.length()-1);
		
		String rev="";
		
		for (int i=remainStr.length()-1;i>=0;i--){
			
			rev= rev+remainStr.charAt(i);
		}
		
		System.out.println(rev);
		
		String str1 = new String();
		str1=rev+fch;
		
		System.out.println(str1);
		//System.out.println(fch.concat(rev));
		
		System.out.println(fch);
		
		System.out.println(remainStr);
		
		
		int sum1=0;
		int[][] arr1 = {	{3,2,4},
						{7,8,9},
						{13,4,10}};
		
		for(int i = 0;i<arr1.length;i++){
			
			sum1 += arr1[i][i];

		}
		
		System.out.println(sum1);
		//System.out.println(Arrays.toString(arr));
		
		
		
		System.out.println('j'+'a'+'v'+'a');

		
	}

}
