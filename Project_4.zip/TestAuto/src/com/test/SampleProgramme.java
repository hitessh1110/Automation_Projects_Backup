package com.test;

import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.stream.Stream;

import org.omg.Messaging.SyncScopeHelper;

public class SampleProgramme {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		for (int i=0;i<5;i++){
			for (int j=5;j>i;j--){
				
				System.out.print("* ");
			}
			
			System.out.println();
		}
		
/*
 * Find the duplicate in the string using Brut Force Method
 */
	

  int dup [] = {2,4,5,6,2,8,4,2};
  
  for (int i=0;i<dup.length;i++){
	  
	  for (int j=i+1;j<dup.length;j++){
		  
		  if (dup[i]==dup[j] &&  i!=j){
			  
			  System.out.print(dup[j]+" ");
		  }
		  
		  
	  }
	  
  }
  System.out.println();

	/*
	 * By using set 
	 * 	
	 */
		
	Set<Integer> dupset= new HashSet<>();	
     
	    for (int i =0 ;i<dup.length;i++){
	    	
	    	if(dupset.add(dup[i])==false){
	    		
	    		System.out.println(dup[i]);
	    		
	    	}
	    	
	    }
	
	    System.out.println("****************************************************");
	    
	    /* 
		 * By using Map Interface
		 * 	
		 */
  
	    Map<Integer,Integer> hm = new HashMap<>();
	    
	    for(int num : dup){
	    	
	    	Integer count =hm.get(num);
	    	if(count==null){
	    		hm.put(num, 1);
	    		
	    	} else {
	    		
	    		count=count+1;
	    		hm.put(num, count);
	    	}
	    	
	    }
	    
	    Set<Map.Entry<Integer, Integer>> es = hm.entrySet();
	    System.out.println(es);
	    for(Map.Entry<Integer, Integer> me :es){
	    	// System.out.println(me);
	    	if (me.getValue()>1){
	    		System.out.println(me.getKey());
	    		
	    	}
	    	
	    }
	    
	  System.out.println("***************************************");
	  
	  
	    char dupstr[] = {'a','s','e','a','v','f','s','e','a'};
	    
	    //char arrch[] = {'t','f'};
	    
	    Map<Character,Integer> hm1 = new HashMap<>();
	    
	    String str = "college";
	      
	    char[] ch= str.toCharArray();
	    
	    for(char ch1 : dupstr){
	    	
	       if (hm1.containsKey(ch1)){
	    	   
	    	   hm1.put(ch1, hm1.get(ch1)+1);
	       } else{
	    	   hm1.put(ch1,1);
	    	   
	       }
	    	
	
	    	
	    }
	    
	    Set<Map.Entry<Character, Integer>> es1 = hm1.entrySet();
	    
	  es1.stream().sorted(Map.Entry.comparingByValue()).forEach(System.out::println);
	   
	    
//	    for (Map.Entry<Character, Integer> me : es1){
//	    	
//	    	System.out.println(me);
//	    }
		
		
		int arr[] = { 3, 4, 1, 456, 78, 90, 23 };
		
		int arr1[] = {10,20,30,40,50,60};
		 System.out.print("Array before sort:-");
		for (int k = 0; k < arr.length; k++) {
			System.out.print(arr[k]+" ");

		}
        
		System.out.println();
		bubbleSort(arr);
		
		 System.out.print("Array After sort:-");
		for (int k = 0; k < arr.length; k++) {
			System.out.print(arr[k]+" ");

		}
		
		System.out.println();
		BinarySearch(arr1,20);
		
		 
	}
	//int arr[] = { 3, 4, 1, 456, 78, 90, 23 };
	public static void bubbleSort(int[] abc) {
		int n = abc.length;
		int temp = 0;
		int count =0;

		for (int i = 0; i < n; i++) {

			for (int j = 1; j < (n - i); j++) {

				if (abc[j - 1] > abc[j]) {
                    System.out.println(abc[j-1]);
					temp = abc[j - 1];
					abc[j - 1] = abc[j];
					abc[j] = temp;
                  count++;
				}

			}

		}
  
		System.out.println("--- " +count);
	}
	
	public static void BinarySearch( int [] k , int key){
		
		int flag=0;
		int low = 0;
		int high= k.length-1;
		
		int mid = (low+high)/2;
		while(low<=high){
			
			
			
			if(key==k[mid]){
				
				flag =1;
				break;
			}
			else if (key<k[mid]){
				high=mid-1;
				
			} else {
				low=mid+1;
			}
			
			 mid = (low+high)/2;
		}
		 if (flag==1){
			 
			
			System.out.println("key is found " +k[mid]+ " at " +mid);
		 } else {
			 
			 System.out.println("element not found");
		 }
		
		
		
	}
	
	
	

}
