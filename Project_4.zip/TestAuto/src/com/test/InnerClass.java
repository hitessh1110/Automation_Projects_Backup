package com.test;

public class InnerClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
