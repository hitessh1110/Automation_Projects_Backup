package com.test;

import java.awt.List;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

import com.univocity.parsers.csv.CsvParser;
import com.univocity.parsers.csv.CsvParserSettings;

public class CompareCSV {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

//		try {
//			readFile("D:\\Eclipse_1\\SampeCSV1.csv");
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
		
		
		
		
		
	}
	
	  public Reader getReader(String path) throws UnsupportedEncodingException {
	      
	        return new InputStreamReader(this.getClass().getResourceAsStream(path), "UTF-8");
	    
	    }
	
	
	
	public static void readFile(String path) throws IOException{
		
		//FileInputStream fi = new FileInputStream(new File(""));
		
		File file = new File(path);
		
		BufferedReader br = new BufferedReader(new FileReader(file));
		
	//	String Firstline = br.readLine();
		 
		while (br.readLine()!=null){
			
			String [] strarray  = br.readLine().split(",");
			
			for (String str1 : strarray){
				System.out.print(str1);
			}
			System.out.println();
			
		}
		
		
		
		
		
	}
	
	
	public void readfileviaParser(){
		
		CsvParserSettings setting  = new CsvParserSettings();
		setting.getFormat().setLineSeparator(",");
		CsvParser parser = new CsvParser(setting);
		
		//List <String[]> allrows = parser.parseAll(getReader("D:\\Eclipse_1\\SampeCSV1.csv"));
		
		
		
	}
	

	

	
	
	
	
	
	

}
