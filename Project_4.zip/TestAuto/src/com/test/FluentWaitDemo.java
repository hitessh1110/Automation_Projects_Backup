package com.test;

import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;

import com.google.common.base.Function;

public class FluentWaitDemo {
	
	
	
	
	//private static final String WebElelement = null;

	public static void test() throws Exception{
		
		
		WebDriver driver =  new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.get("https://www.google.com/");
		driver.findElement(By.xpath("//input[@class='gLFyf gsfi']")).clear();
		driver.findElement(By.xpath("//input[@class='gLFyf gsfi']")).sendKeys("Hitesh");
		driver.findElement(By.xpath("(//input[@value='Google Search'])[2]")).sendKeys(Keys.RETURN);
		
	//	driver.findElement(By.partialLinkText("ABCD - Wikipedia")).click();
		
		
		Wait<WebDriver> wait  = new FluentWait<WebDriver>(driver)
				.withTimeout(30, TimeUnit.SECONDS)
				.pollingEvery(2, TimeUnit.SECONDS)
		        .ignoring(NoSuchElementException.class);
		
		
		
		WebElement element =  wait.until(new Function<WebDriver ,WebElement >() {
			public WebElement apply (WebDriver driver){
				WebElement linkElement =  driver.findElement(By.xpath("//span[text() ='Hitesh - Wikipedia']"));
				
				if (linkElement.isEnabled()){
					
					System.out.println("Element Found"  +linkElement.getText());
					
				}
				
				return linkElement;
			}
			
			
			
		});
		
		element.click();
		
		Thread.sleep(2000);
		
		driver.quit();
	}

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		
		test();

	}

}
