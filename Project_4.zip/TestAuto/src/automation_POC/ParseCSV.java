package automation_POC;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class ParseCSV {
	
//	
//	@Test (dataProvider="testData")
//	public void testDatefromFile (String year, String industry_code_ANZSIC,String industry_name_ANZSIC,String rme_size_grp,String variable,String value,String unit){
//		
//		System.out.println(year);
//		System.out.println(industry_code_ANZSIC);
//		System.out.println(industry_name_ANZSIC);
//		System.out.println(rme_size_grp);
//		System.out.println(variable);
//		System.out.println(value);
//		System.out.println(unit);
//	}
//	
	
	

	private Iterator<Object[]> parseCsvData(String fileName) throws IOException {
		BufferedReader input = null;
		File file = new File(fileName);
		input = new BufferedReader(new FileReader(file));
		String line = null;
		ArrayList<Object[]> data = new ArrayList<Object[]>();
		while ((line = input.readLine()) != null) {
			String in = line.trim();
			String[] temp = in.split(",");
			List<Object> arrray = new ArrayList<Object>();
			for (String s : temp) {
				arrray.add(s);
			}
			data.add(arrray.toArray());
		}
		input.close();
		return data.iterator();
	}
	
	
	
	
	/**
	  Use the above method in dataprovider
	**/
	@DataProvider(name = "testData")
	public Iterator<Object[]> testData() throws IOException
	{
	  return parseCsvData("D:\\Eclipse_1\\SampeCSV1_Hitesh.csv");
	}

}
