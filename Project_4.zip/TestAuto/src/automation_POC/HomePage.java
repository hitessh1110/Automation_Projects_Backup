package automation_POC;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class HomePage {
	
	   WebDriver driver; 
	  
	    public HomePage(WebDriver driver) { 
	        this.driver = driver; 
	    } 
	  
	    // Using FindBy for locating elements 
	    @FindBy(how = How.XPATH, using =  
	            "//div[@class='col-sm-8 col-xs-8 col-md-8']//h1") 
	    WebElement titleOfPage; 
	  
	    
	    public String getTitle() { 
	    	
	    	return titleOfPage.getText(); 
	    	
        } 

}
