package automation_POC;

import org.testng.annotations.Test;

public class TestClass {
	
	
	@Test (dataProvider="testData",dataProviderClass=ParseCSV.class)
	public void testDatefromFile (String year, String industry_code_ANZSIC,String industry_name_ANZSIC,String rme_size_grp,String variable,String value,String unit){
		
		System.out.println(year);
		System.out.println(industry_code_ANZSIC);
		System.out.println(industry_name_ANZSIC);
		System.out.println(rme_size_grp);
		System.out.println(variable);
		System.out.println(value);
		System.out.println(unit);
	}
	

}
