package programme;

public class PYRAMID_PROGRAM {
	
	
	
		public static void main(String[] args) {
			
			//  Start Pyramid Program upwards
		    
		    for (int i = 0 ; i < 5 ; i++){
		        
		        for (int k = 5 ; k >i ; k--){
		            
		            System.out.print(" ");
		        }
		        
		        for (int j = 0 ; j<=i; j++){
		            
		            System.out.print("* ");
		        }
		        
		        System.out.println();
		    }
		    
		    System.out.println();
       //  Start Pyramid Program inverted
		    
		    for (int i = 5 ; i > 0 ; i--){
		        
		        for (int k = 5 ; k >=i ; k--){
		            
		            System.out.print(" ");
		        }
		        
		        for (int j = 0 ; j<i; j++){
		            
		            System.out.print("* ");
		        }
		        
		        System.out.println();
		    }
		    
		    
		    
		//	System.out.println("Hello World " + max + " " + x + " " +y);
		}
	}


