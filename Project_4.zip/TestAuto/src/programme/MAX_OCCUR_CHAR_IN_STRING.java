package programme;

import java.util.Arrays;
import java.util.HashMap;

public class MAX_OCCUR_CHAR_IN_STRING {
	
	public static void removeDuplicatefromArray(String arr[]){
		
		Arrays.sort(arr);
		String temp[] = new String [arr.length];
		System.out.println(Arrays.toString(arr));
		int j =0;
		
		int n = arr.length;
		
		for (int i =0; i< n-1; i++){
			
			if (arr[i] != arr [i+1]){
				temp[j++] = arr[i];
				
			}
			
		}
		
		
		temp[j++] = arr[n-1];
		
		System.out.println(Arrays.toString(temp));
		
		for (int k=0; k<j; k++ ){
			
			System.out.print(temp[k]);
		}
		
	}
	
	
	public static void getSecondHightestValue(int arr[]){
		
		int temp;
		
		for (int i =0;i< arr.length-1; i++){
		
			 if (arr[i]> arr[i+1]){
				 
				 temp = arr[i];
				 arr[i] = arr[i+1];
				 arr[i+1] = temp;
				 
				 i = -1;
			 }
			
		}
		
		System.out.println(Arrays.toString(arr));
		
		System.out.println(arr[arr.length-2]);
	}
	
	
	
	
	
	

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		
		HashMap<String, String> map = new HashMap<>();
		map.put("1", "a");
		map.put("2" , "b");
		map.put("3", "a");
		map.put("1", "c");
		
		System.out.println(map);
		
		String arr1 [] = {"a","b","a","c","b","d","e"};
		
		int arr2 [] = {2,3,5,7,1,8,9};
		
		removeDuplicatefromArray(arr1);
		System.out.println();
		
		
		getSecondHightestValue(arr2);

	}

}
