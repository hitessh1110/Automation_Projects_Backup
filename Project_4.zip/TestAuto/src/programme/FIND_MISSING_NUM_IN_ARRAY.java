package programme;

import java.util.HashSet;

public class FIND_MISSING_NUM_IN_ARRAY {
	
	
	
	public static void getMissingNum( int arr[]) {
		
		HashSet<Integer> set = new HashSet<Integer>();
		
		for (int i = arr[0]; i < arr[arr.length -1] ; i++){
			
			set.add(i);
		}
		
		for (int j =0 ; j < arr.length ; j++ ){
			
			set.remove(arr[j]);
		}
		
		// Print the missing numbers
		System.out.println("The Missing numbers in an array are");
		
		for (int x : set){
			
			System.out.print(" " +x);
		}
		
		
	}
	
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int [] arr = {2,6,10};
		
		getMissingNum(arr);
		
		String a1 ="John";
		String a2= "Jo" + "hn";
		String a3 = "Jo".concat("hn");
		
		System.out.println(a1==a2);
		System.out.println(a1.equals(a2));
		System.out.println(a1==a3);
		System.out.println(a2==a3);
		
//		String str;
//		try{
//			
//			str = (String) (Object)0;
//		} catch(Exception e){
//		     e.printStackTrace();
//		}
		
		

	}

}
