package testScript;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Selenium_Waits {
	
	static WebDriver  driver;

//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//		
//		
//			
//		
//		Wait <WebDriver> wait = new FluentWait<WebDriver>(driver)
//				
//			       .withTimeout(30, TimeUnit.SECONDS)
//			       .pollingEvery(5, TimeUnit.SECONDS)
//			       .ignoring(NoSuchElementException.class);
//		
//		
//		
//		
//	}
	
	
	
	

}
