package com.aditya.testData;

import java.util.Arrays;

public class test {

	public static void main(String[] args) 
	{
		String [][] arr = new String[0][2];
					arr[0][0] = "AA";
					arr[0][1]= "bb";
		System.out.println(Arrays.deepToString(arr));

	}

}
